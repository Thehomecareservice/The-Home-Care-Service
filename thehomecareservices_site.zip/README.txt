
The Home Care Service - static website
-------------------------------------
Files in this folder can be uploaded directly to GitHub as a repo and deployed to Vercel/Netlify.
- Open index.html in a browser to preview locally.
- Images are in the 'images' folder.

Contact/WhatsApp: +91-7347323627
Address: 18 Hermitage Centralis Market, VIP Road, Zirakpur 140603
